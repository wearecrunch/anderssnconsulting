

### 7.0.4 - 25/05/2015

 Changes: 


 * * fixed issue with tweet length
* fixed issue with facebook hashtag
 * * added bussines version


### 7.0.4 - 16/04/2015

 Changes: 


 * * fixed bug with the new facebook api changes.
* changed pro banner
 * Merge branch 'development' of https://github.com/Codeinwp/tweet-old-post into development


### 7.0.3 - 03/04/2015

 Changes: 


 * * fixed problem with media_id
 * * fixed bug with logs reporting in system info where there is no log available.
 * Update readme.txt
 * Update readme.txt


### 7.0.2 - 26/03/2015

 Changes: 


 * * Removed twitter update_with_media call.
* Fixed activation error notices when WP_DEBUG was enabled
 * Merge remote-tracking branch 'origin/development' into development


### 7.0.1 - 06/03/2015

 Changes: 


 * http bug
 * Final version of tweet old post
 * final vers
 * Added Top 5.7 version
 * added strlower
 * Tweets now are posted immediately, fixed scheduling and added debug messages
 * latest stable version 6.2
 * added exclude posts back
 * latest major fixes
 * fixed interrupted posting
 * Added settings link, fixed tweet cutting and added cron debug messages

Added settings link, fixed tweet cutting and added cron debug messages
 * latest top fixes [stable version ]
 * almost added fb
 * stable version with linkedin + facebook
 * custom icon, final fixes
 * fixed fb instructions + small css things
 * Set up localization and translation
 * 6.8.1 with multi-language + cpt support
 * fix post issue
 * various small fixes to encoding
 * various fixes

* fix for coma on the exclude post page
* fixed the shortner problem that was not adding the analytics.
* fixed the cron issue
 * increased notification time check by *5

increased notification time check by *5
 * * Added post format per network
* Rearranged the options
 * Merge remote-tracking branch 'origin/development' into development
 * * Fixes for no account post sharing issue
* Added immediately share after start
 * redesign and on/off button
 * * Improved tabs graphic
* Added remote cron check
 * * added pro badge for linkedin post format
* fixed compatibility issue with older versions
 * * added pro badge for linkedin post format
* fixed compatibility issue with older versions
 * * fixed the relative path issue
 * Update readme.txt
 * * fixed issue with notices
* solved some cron compatibilty problems
 * * fixed double posting issue for cron
 * * fixed backwards compatibility issue
 * Removed useless spaces in post format
 * fixed custom field from url issue
 * * fixed problem with oauth time
* fixed problem with cron time
 * * fixed problem with oauth time
* fixed problem with cron time
 * Merge remote-tracking branch 'origin/development' into development
 * Update core.php
 * Update tweet-old-post.php
 * Update view.php
 * Update OAuth.php
 * Update tweet-old-post.php
 * * added more complex log system
* improved cron schedule
 * Merge remote-tracking branch 'origin/development' into development
 * * fixed sample tweet
* added support for pro version
 * * added clock feature
 * * fix for old cron
* fix sample tweet image
 * * removed console clock
 * Update readme.txt
 * Fixed https request
 * Update tweet-old-post.php
 * Update core.php
 * Update style.css
 * Update tweet-old-post.php
 * * fixed typo bugs.
 * Update readme.txt
 * * fixed excluded post bug
* fixed cron time issue
* added more log types messages
* improved system info
 * Merge remote-tracking branch 'origin/development' into development
 * * update version
 * * added sib banner
 * * updated changelog
 * * fixed bug with share more than once.
 * Update tweet-old-post.php
 * Update view.php
 * * Fixed issue cron stop
* Fixed issue for excluded post
* Added exclude posts from custom post types.
 * Merge remote-tracking branch 'origin/development' into development
 * * Fixed issue cron stop
* Fixed issue for excluded post
* Added exclude posts from custom post types.
 * updated version
 * * fixed sample post issue
 * * fixed tweet custom field url
 * * changed version
 * fixed minutes typo
 * *  rollback generate tweet
 * Merge remote-tracking branch 'origin/development' into development
 * *  fixed image compatibility
 * * fixed pro compatibility
 * Update readme.txt
 * buttons added: Google Plus, XING , Stumbleupon , Tumblr
 * strip html response.
 * * rewrite the tweet generation
* added usefull filtes and hooks
 * * Fixed issue with duplicate posting
* Added Xing and Tumbr Networks
* Fixed issue with random posts on large databases.
 * * Fixed issue with duplicate posting
* Added Xing and Tumbr Networks
* Fixed issue with random posts on large databases.
 * * Fixed no link issue
* Added new info to System Log
 * * FIxed compatibilty issues with old pro version
 * * added chacter count when media is active
 * * fixed link position in tweets.
 * * removed only pro badge on custom schedule secundar tabs
 * * fixed problem with strange chars in tweets.
